"""
Location routes package.
"""
from app.api.routes.location.location_type_routes import router as location_type_router
from app.api.routes.location.location_routes import router as location_router