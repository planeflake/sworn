"""
Location services package.
"""
from app.game_state.services.location.location_type_service import LocationTypeService
from app.game_state.services.location.location_service import LocationService