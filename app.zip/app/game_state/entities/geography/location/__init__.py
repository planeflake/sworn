"""
Location package for location-related entities.
"""
from app.game_state.entities.geography.location.location_type import LocationTypeEntity
from app.game_state.entities.geography.location.location_reference import LocationReference
from app.game_state.entities.geography.location.location import LocationEntity