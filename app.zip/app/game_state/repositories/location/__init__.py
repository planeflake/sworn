"""
Location repositories package.
"""
from app.game_state.repositories.location.location_type_repository import LocationTypeRepository
from app.game_state.repositories.location.location_repository import LocationRepository