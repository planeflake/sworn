"""
Domain Entity Generator

A tool to automate the creation of domain entities and related components from SQLAlchemy models.
"""

__version__ = "0.1.0"